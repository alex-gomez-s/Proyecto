# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 13:34:46 2024

@author: nftorres
"""

