from Services.Transforms import Transforms
from Services.Load import LoadData
from Services.Extract import ConnSQL
from Config.Parametros import ParametrosConnect as CONN

def fact_recaudo_mobilidad():
    """

    """
    # Establecer coneccion a la base de datos
    conn = ConnSQL(server=CONN.server_15, database=CONN.database_15)
    conn.connect()
    # Parametrizacion de la consulta
    querysql1 = "SELECT * FROM ##CLIENTES_DIGITALES"
    querysql2 = "SELECT * FROM #REACAUDO_MOBILIDAD"
    # ejcutacion de consulta y cierre de la conexion
    conn.ejecutar_sql_script(archivo_sql=CONN.path_sql_digital,query=querysql1)   
    conn.ejecutar_sql_script(archivo_sql=CONN.path_sql_recuado,query=querysql2)
    conn.close()
    # Transformacion de datos
    df_transforms = Transforms(path=None,datos=conn.df,file_type='DataFrame')

    # Cargar datos
    df_salida = LoadData(datos=df_transforms.df, full_path=CONN.path_salida)
    df_salida.load_data(name_file='Recaudo', type_file='excel',date_=True)
