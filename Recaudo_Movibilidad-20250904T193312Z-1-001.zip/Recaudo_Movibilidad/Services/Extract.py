import pandas as pd
import pyodbc
import os
from Services.otras_funcionalidades import detectar_codificacion

class ConnSQL:
    """
    ConnSQL se conecta a un servidor y una base de datos de SQL Server.
    """
    def __init__(self, server, database):
        self.server = server
        self.database = database
        self.connection = None
        self.df = None
    
    def connect(self):
        """
        Establece la conexión a la base de datos.
        """
        try:
            self.connection = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};'
                f'SERVER={self.server};'
                f'DATABASE={self.database};'
                'Trusted_Connection=yes;'
                'CHARSET=UTF8;'
            )
            print(f'Conexión exitosa a la base de datos: {self.database}')
            return self.connection

        except pyodbc.Error as e:
            print(f'Error al conectarse a la base de datos: {e}')
            return None

    def close(self):
        """
        Cierra la conexión a la base de datos.
        """
        if self.connection:
            self.connection.close()
            print('Conexión cerrada correctamente.')
        else:
            print('No hay conexión activa para cerrar.')
            
    def query_to_dataframe(self, query):
        """
        Ejecuta una consulta SQL y devuelve el resultado como un DataFrame de pandas.
        """
        try:
            if self.connection:
                self.df = pd.read_sql(query, self.connection)
                print(f'Consulta ejecutada exitosamente. Filas obtenidas: {len(self.df)}')
                return self.df
            else:
                print('No hay conexión activa.')
                return None
        except Exception as e:
            print(f'Error al ejecutar la consulta: {e}')
            return None

    def execute_stored_procedure(self, proc_name, params=None):
        """
        Ejecuta un procedimiento almacenado con o sin parámetros.
    
        Args:
            proc_name (str): Nombre del procedimiento almacenado.
            params (tuple, opcional): Parámetros del procedimiento. Por defecto es None.
    
        Returns:
            None
        """
        try:
            if not self.connection:
                print("No hay conexión activa.")
                return None  # Retorna None si no hay conexión
     
            cursor = self.connection.cursor()
     
            if params:
                cursor.execute(f"EXEC {proc_name} {', '.join(['?' for _ in params])}", params)
            else:
                cursor.execute(f"EXEC {proc_name}")
     
            self.connection.commit()
            print(f'Procedimiento {proc_name} ejecutado exitosamente')
    
            # Si necesitas retornar datos del procedimiento almacenado
            return cursor.fetchall() if cursor.description else None
     
        except pyodbc.Error as e:
            print(f"Error al ejecutar el procedimiento almacenado: {e}")
            return None
    
    def ejecutar_sql_script(self, archivo_sql, query):
        if not self.connection:
            print("No hay conexión activa. Conéctate primero.")
            return None
    
        try:
            cursor = self.connection.cursor()
    
            # Detectar la codificación del archivo SQL
            encoding = detectar_codificacion(archivo_sql)
    
            # Leer el archivo con la codificación detectada
            with open(archivo_sql, 'r', encoding=encoding) as archivo:
                script_sql = archivo.read()
    
            # Ejecutar el script SQL
            cursor.execute(script_sql)
            self.connection.commit()  # Confirma las operaciones
    
            # Ejecutar la consulta SQL y devolver el DataFrame
            self.df = pd.read_sql(query, self.connection)
            print(f'Consulta ejecutada exitosamente. Filas obtenidas: {len(self.df)}')
            return self.df
    
        except pyodbc.Error as e:
            print(f"Error al ejecutar el comando: {e}")
            raise
    
        finally:
            cursor.close()  # Asegura que el cursor se cierre en caso de error

            

class Extract:
    """
    Extract extrae información de distintas fuentes de datos.
    """
    def __init__(self, path=None, name_file=None, sep=None):
        self.path = path
        self.name_file = name_file
        self.sep = sep
        self.df = None
    
    def read_DataFrame(self,datos):
        self.df = pd.DataFrame(datos)

    def read_file_txt(self):
        """
        Lee un archivo de texto (CSV) y devuelve un DataFrame.
        Maneja excepciones si el archivo no se encuentra o hay problemas al leer.
        """
        try:
            # Verificar que path y archivo no sean None
            if not self.path or not self.name_file:
                raise ValueError("El 'path' y 'name_file' son obligatorios.")

            # Generar la ruta completa al archivo
            full_path = os.path.join(self.path, self.name_file)

            # Leer el archivo CSV en un DataFrame
            self.df = pd.read_csv(full_path, encoding='utf-8', sep=self.sep)
            print(f"Archivo '{self.name_file}' leído correctamente.")
            return self.df

        except pd.errors.EmptyDataError:
            print(f"Error: El archivo '{full_path}' está vacío.")
            return None

        except ValueError as e:
            print(f"Error de valor: {e}")
            return None

        except Exception as e:
            print(f"Se produjo un error inesperado: {e}")
            return None

    def read_folder(self):
        """
        Lee todos los archivos en formato texto (.txt) de una carpeta dada y 
        concatena los datos en un único DataFrame.

        Returns:
            pd.DataFrame: DataFrame resultante de la concatenación de los archivos.
        """
        try:
            # Verificar que la ruta no sea None
            if not self.path:
                raise ValueError("El 'path' es obligatorio.")

            # Inicializar una lista para almacenar los DataFrames
            files = []

            # Recorrer los archivos dentro de la carpeta
            for folder_name, _, file_names in os.walk(self.path):
                for file_name in file_names:
                    # Verificar si el archivo es .txt
                    if file_name.endswith('.txt'):
                        file_path = os.path.join(folder_name, file_name)
                        try:
                            # Leer el archivo en un DataFrame
                            df = pd.read_csv(file_path, sep=self.sep, encoding='utf-8')
                            files.append(df)
                            print(f"Archivo '{file_name}' leído correctamente.")
                        except pd.errors.ParserError:
                            print(f"Error al parsear el archivo: {file_name}")
                        except Exception as e:
                            print(f"Error inesperado con '{file_name}': {e}")

            # Verificar si se encontraron archivos válidos
            if files:
                # Concatenar todos los DataFrames en uno solo
                self.df = pd.concat(files, axis=0, ignore_index=True)
                print("Archivos concatenados exitosamente.")
                return self.df
            else:
                print("No se encontraron archivos .txt válidos.")
                return None

        except ValueError as e:
            print(f"Error de valor: {e}")
            return None


    def read_folder_excel(self, sheet_name=None):
        """
        Lee todos los archivos en formato Excel (.xlsx) de una carpeta dada y 
        concatena los datos en un único DataFrame.

        Args:
            sheet_name (str, optional): Nombre de la hoja a leer. Si es None, se leen todas las hojas.

        Returns:
            pd.DataFrame: DataFrame resultante de la concatenación de los archivos.
        """
        try:
            if not self.path:
                raise ValueError("El 'path' es obligatorio.")

            files = []

            for folder_name, _, file_names in os.walk(self.path):
                for file_name in file_names:
                    if file_name.endswith('.xlsx'):
                        file_path = os.path.join(folder_name, file_name)
                        try:
                            # Leer archivo Excel
                            excel_data = pd.read_excel(file_path, sheet_name=sheet_name)

                            if isinstance(excel_data, dict):
                                # Si se leen todas las hojas, concatenarlas
                                for sheet, df in excel_data.items():
                                    print(f"Hoja '{sheet}' del archivo '{file_name}' leída correctamente.")
                                    files.append(df)
                            else:
                                # Si se lee una hoja específica
                                print(f"Archivo '{file_name}' leído correctamente.")
                                files.append(excel_data)
                        except FileNotFoundError:
                            print(f"Archivo no encontrado: {file_name}")
                        except ValueError as e:
                            print(f"Error en el archivo '{file_name}': {e}")
                        except Exception as e:
                            print(f"Error inesperado con '{file_name}': {e}")

            if files:
                self.df = pd.concat(files, axis=0, ignore_index=True)
                print("Archivos concatenados exitosamente.")
                return self.df
            else:
                print("No se encontraron archivos .xlsx válidos.")
                return None

        except ValueError as e:
            print(f"Error de valor: {e}")
            return None
        except Exception as e:
            print(f"Se produjo un error inesperado: {e}")
            return None

    def read_file_excel(self,sheet_name):
        """
        Lee un archivo de excel (.xlsx) y devuelve un DataFrame.
        Maneja excepciones si el archivo no se encuentra o hay problemas al leer.
        """
        try:
            # Verificar que path y archivo no sean None
            if not self.path or not self.name_file:
                raise ValueError("El 'path' y 'name_file' son obligatorios.")

            # Generar la ruta completa al archivo
            full_path = os.path.join(self.path, self.name_file)

            # Leer el archivo CSV en un DataFrame
            self.df = pd.read_excel(full_path,sheet_name=sheet_name)
            print(f"Archivo '{self.name_file}' leído correctamente.")
            return self.df

        except pd.errors.EmptyDataError:
            print(f"Error: El archivo '{full_path}' está vacío.")
            return None

        except ValueError as e:
            print(f"Error de valor: {e}")
            return None

        except Exception as e:
            print(f"Se produjo un error inesperado: {e}")
            return None
        
