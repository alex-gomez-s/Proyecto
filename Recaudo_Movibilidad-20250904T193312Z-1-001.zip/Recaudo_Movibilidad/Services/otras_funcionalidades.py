import chardet

def detectar_codificacion(archivo_sql):
    with open(archivo_sql, 'rb') as f:
        resultado = chardet.detect(f.read())
    return resultado['encoding']

