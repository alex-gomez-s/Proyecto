# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 13:04:03 2024

@author: nftorres
"""

