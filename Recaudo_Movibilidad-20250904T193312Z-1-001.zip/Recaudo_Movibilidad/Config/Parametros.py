
class ParametrosConnect:
    server_8 = '10.200.98.8'
    server_15 = '10.200.98.15'
    database_8 = 'BD_COMERCIAL'
    database_15 = 'BMIA_DWH'
    path_salida = r'G:\Unidades compartidas\GIN - GBDNN\Recaudo Movilidad\Base'
    path_sql_digital = r'C:\Users\NFTORRES\proyectos\Recaudo_Movibilidad\Archivos_Sistema\1. Clientes digitales.sql'
    path_sql_recuado = r'C:\Users\NFTORRES\proyectos\Recaudo_Movibilidad\Archivos_Sistema\2.Recaudo_PagosPrestamos.sql'