from Models.fact_recaudo_mobilidad import fact_recaudo_mobilidad

def app():
    fact_recaudo_mobilidad()


if __name__ == '__main__':
    app()